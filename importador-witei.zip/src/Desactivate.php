<?php
namespace CHWITEI;
 
class Desactivate
{
    /*
    *
    */
    public static function index()
    {

    }
}
