<?php

namespace CHWITEI;

final class Config
{

    /**
     * @var Config
     */
    private static $instance;

    /**
     * gets the instance via lazy initialization (created on first usage)
     */
    public static function getInstance(): Config
    {
        if (null === static::$instance) {
            static::$instance = new static();
        }

        return static::$instance;
    }

    /**
     * is not allowed to call from outside to prevent from creating multiple instances,
     * to use the singleton, you have to obtain the instance from Config::getInstance() instead
     */
    private function __construct()
    {
        //
    }

    /**
     * prevent the instance from being cloned (which would create a second instance of it)
     */
    private function __clone()
    {
        //
    }

    /**
     * prevent from being unserialized (which would create a second instance of it)
     */
    public function __wakeup()
    {
        //
    }
    /*
    * Plugins option
    * storage in database the option value
    * Array ('option_name'=>'default value')
    * @example ["example_data" => 'foo',]
    * @return void
    */
    public $plugin_options=[
        'witei_post_type'           => '',
        'witei_user_publish'        => '',
        'witei_xml_url'             => '',
        'witei_referencia'          => 'witei_id',
        'witei_wpml'                => '',
        'witei_importar_fotos'      => '',
        'witei_reemplazar_fotos'    => '',
        'witei_activar_cron'        => '',
        'witei_notificar_email'     => '',
        'witei_cron_email'          => '',
        'witei_webhook_xml'         => '',
        'witei_key_api'             => '',
        'import_support_name'       => '',
        'status_venta'              => 'VENTA',
        'status_alquiler'           => 'ALQUILER',
        'witei_token'               => '',
        'ch_token'                  => '',
        'import_xml'                => '{}',
        'import_json'               => '{}',
        'inmo_tags'                 => [],
        
    ];
    /**
    * Language Option
    * define a unique word for translate call
    */
    public $language_name='ch_witei';
    /**
    * Plugin text prefix
    * define a unique word for this plugin
    */
    public $plugin_prefix='ch_antonella';
    /**
    * POST data process
    * get the post data and execute the function
    * @example ['post_data'=>'CHWITEI::function']
    */
    public $post=[
        'ch_witei_admin'=>__NAMESPACE__.'\Admin\PageAdmin::guardar'
    ];
    /**
    * GET data process
    * get the get data and execute the function
    * @example ['get_data'=>'CHWITEI::function']
    */
    public $get=[
        'cron'  => __NAMESPACE__."\WiteiController::ProgramarImportacion",
    ];
    /**
    * add_filter data functions
    * @input array
    * @example ['body_class','CHWITEI::function',10,2]
    * @example ['body_class',['CHWITEI','function'],10,2]
    */
    public $add_filter=[];
    /**
    * add_action data functions
    * @input array
    * @example ['body_class','CHWITEI::function',10,2]
    * @example ['body_class',['CHWITEI','function'],10,2]
    */
    public $add_action=[
        ['save_post',[__NAMESPACE__.'\WiteiController','parentAfterSavePost'],10,3],
      //  ['save_post',[__NAMESPACE__."\WiteiController","ExportarWitei"],10,3],
        // AJAX
        ['wp_ajax_import_witei',__NAMESPACE__.'\WiteiController::importar_api'],
        ['wp_ajax_import_support',__NAMESPACE__.'\WiteiController::ImportarConfiguracion'],
        ['wp_ajax_import_undo',__NAMESPACE__.'\WiteiController::DeshacerConfiguracion'],
        ['wp_ajax_nopriv_import_undo',__NAMESPACE__.'\WiteiController::DeshacerConfiguracion'],
        ['wp_ajax_nopriv_import_support',__NAMESPACE__.'\WiteiController::ImportarConfiguracion'],
        ['wp_ajax_import_witei_foto',__NAMESPACE__.'\WiteiController::parentInsertar_foto'],
        ['wp_ajax_nopriv_import_witei_foto',__NAMESPACE__.'\WiteiController::parentInsertar_foto'],
        ['wp_ajax_borrar_excedentes',__NAMESPACE__.'\WiteiController::parentDeleteProperties'],
        ['wp_ajax_witei_test',__NAMESPACE__.'\WiteiController::FindByID'],
        ['wp_ajax_nopriv_witei_test',__NAMESPACE__.'\WiteiController::FindByID'],
        ['wp_ajax_nopriv_witei_cron',__NAMESPACE__."\WiteiController::ProgramarImportacion"],
        ['wp_ajax_nopriv_witei',__NAMESPACE__."\WiteiController::ImportWebhook"],
        ['wp_ajax_witei',__NAMESPACE__."\WiteiController::ImportWebhook"],
        ['wp_ajax_send_feedback_email',__NAMESPACE__."\WiteiController::sendFeedBackEmail"],
        ['wp_ajax_add_witei_data_import',__NAMESPACE__."\WiteiController::addWiteiDataImport"],
        ['wp_ajax_witei_count',__NAMESPACE__."\WiteiController::contarInmuebles"],
        ['before_delete_post',[__NAMESPACE__."\WiteiController","WiteiBorrarMediaAntesDeBorrarInmueble"],10,2],
       
    ];
    
    /**
    * add custom shortcodes
    * @input array
    * @example [['example','CHWITEI\ExampleController::example_shortcode']]
    */
    public $shortcodes=[
        ['witei',__NAMESPACE__."CHWITEI\WiteiController::Shortcode"]
    ];
    /**
    * Dashboard
    * @reference: https://codex.wordpress.org/Function_Reference/wp_add_dashboard_widget
    */
    public $dashboard=[
        [
        'slug'      => '',
        'name'      => '',
        'function'  => '',
        'callback'  => '',
        'args'      => '',
        ]

    ];
    /**
    * Files for use in Dashboard
    */
    public $files_dashboard=[];

    /*
    * Plugin menu
    * set your menu option here
    */
    public $plugin_menu=[
        [
            "path"      => ["subpage","tools.php"],
            "name"      => "WITEI import",
            "function"  => __NAMESPACE__."\Admin\PageAdmin::index",
            "slug"      => "ch-witei-import"
        ]
        ];

    public $post_types =[
        [
            'singular'      => '',
            'plural'        => '',
            'slug'          => '',
            'translate'     => false,
            'position'      => 4,
            'taxonomy'      =>['category'],
            'image'         =>'',
        ],

    ];

    /**
     * Widget
     * For register a Widget please:
     * Console: php antonella Widget "NAME_OF_WIDGET"
     * @input array
     * @example public $widget = [__NAMESPACE__.'\YouClassWidget']  //only the class
     */
    public $widgets=[];
    
    }
