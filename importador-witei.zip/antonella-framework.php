<?php

namespace CHWITEI;

/*
Plugin Name: WITEI import
Plugin URI: https://carlos-herrera.com/producto/conector-de-inmuebles-witei-para-wordpress/
Description:Another plugin developed on Antonella Framework for WP
Version: 4.6.2
Author: Carlos Herrera
Author URI: https://carlos-herrera.com
Framework: Antonella Framework for WP
Framework URI: http://antonellaframework.com
License: GPL2+
Text Domain: ch_witei
Domain Path: /languages
*/

defined('ABSPATH') or die(__('Lo siento por aqui no puedes pasar :)'));

/*
 * Begins execution of plugin.
 *
 * @return void

function run_pontewordcamp() {
	if ( is_admin() ) {
		include_once plugin_dir_path( __FILE__ ) . '/src/PluginUpdater.php';
		$config  = array(
			'github_uri' => 'https://api.github.com/repos/fgrweb/pontewordcamp/releases',
			'token'      => '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',
		);
		$updater = new PluginUpdater( $config, __FILE__ );
		$updater->fgr_check_update();
	}
}

run_pontewordcamp();
 */

/*
* Class Caller.
* cuando una clase es llamada hace un include
* al archivo con su mismo nombre
* se respeta mayusculas y minusculas
*
* @return null
*/
define('NELLA_URL', __FILE__);
$loader = require __DIR__.'/vendor/autoload.php';
$antonella = new Start();
